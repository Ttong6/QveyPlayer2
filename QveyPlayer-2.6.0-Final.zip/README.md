# Qvey Player 2.6.0 — Final Build

原生 Android 手机端 Emby 播放器项目。

## 构建环境
- Android Gradle Plugin 9.1.1
- Gradle 9.3.1
- JDK 17
- Android SDK 36 / Build Tools 36.0.0
- applicationId: `com.qvey.player`
- versionCode: `26`
- versionName: `2.6.0`

## GitHub Actions
仓库根目录直接包含 `.github/workflows/build.yml`。Workflow 使用 GitHub Actions 的 Gradle setup，不再检查 ZIP 内是否存在 `gradlew`，因此不会再触发“压缩包里没有 gradlew”的旧错误。

推送到 `main`/`master` 或手动运行 workflow 后，会生成 `app-debug.apk` Artifact；推送 `v*` 标签时同时创建 Release。

## 当前核心功能
- Emby 用户认证
- 读取媒体库
- 电影/剧集项目读取
- Media3/ExoPlayer 播放
- 原生 Android 手机竖屏界面
- 网络权限与 GitHub Actions 自动构建

> 本项目刻意采用 AGP 9.1.1 的内置 Kotlin 路线，不再应用旧的 `org.jetbrains.kotlin.android` 插件。
