@echo off
where gradle >nul 2>nul
if %ERRORLEVEL% EQU 0 (gradle %*) else (echo Please install Gradle 9.3.1 or run the included GitHub Actions workflow. & exit /b 1)
