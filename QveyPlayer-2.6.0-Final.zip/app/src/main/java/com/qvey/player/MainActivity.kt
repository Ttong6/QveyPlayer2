package com.qvey.player

import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.media3.common.MediaItem
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.util.concurrent.Executors

class MainActivity : AppCompatActivity() {
    private val exec = Executors.newSingleThreadExecutor()
    private var player: ExoPlayer? = null
    private lateinit var root: LinearLayout
    private var server = ""
    private var userId = ""
    private var token = ""

    override fun onCreate(savedInstanceState: Bundle?) { super.onCreate(savedInstanceState); showLogin() }
    override fun onDestroy() { player?.release(); exec.shutdown(); super.onDestroy() }

    private fun base(): LinearLayout = LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setPadding(24,24,24,24); setBackgroundColor(0xFF0B0B0B.toInt()) }
    private fun tv(s:String, size:Float=18f)=TextView(this).apply { text=s; textSize=size; setTextColor(0xFFFFFFFF.toInt()); setPadding(0,10,0,10) }
    private fun btn(s:String)=Button(this).apply { text=s; isAllCaps=false }
    private fun edit(hint:String)=EditText(this).apply { this.hint=hint; setTextColor(0xFFFFFFFF.toInt()); setHintTextColor(0xFFAAAAAA.toInt()) }

    private fun showLogin() {
        root=base(); root.addView(tv("Qvey Player",30f)); root.addView(tv("Emby 原生 Android 播放器 · 2.6.0",15f))
        val eServer=edit("服务器地址，例如 https://emby.example.com"); val eUser=edit("用户名"); val ePass=edit("密码"); ePass.inputType=0x81
        root.addView(eServer); root.addView(eUser); root.addView(ePass)
        val b=btn("连接 Emby"); root.addView(b); setContentView(root)
        b.setOnClickListener { server=eServer.text.toString().trim().trimEnd('/'); val u=eUser.text.toString(); val p=ePass.text.toString(); if(server.isBlank()||u.isBlank()){toast("请填写服务器地址和用户名");return@setOnClickListener}; b.isEnabled=false; authenticate(u,p,b) }
    }

    private fun authenticate(user:String, pass:String, button:Button) { exec.execute { try { val dev="QveyPlayer/2.6.0"; val auth="MediaBrowser Client=Qvey Player, Device=Android, DeviceId=qvey-${System.currentTimeMillis()}, Version=2.6.0"; val body=JSONObject().put("Username",user).put("Pw",pass).toString(); val c=conn("$server/Users/AuthenticateByName", "POST", auth); c.doOutput=true; c.setRequestProperty("Content-Type","application/json"); c.outputStream.use{it.write(body.toByteArray())}; val code=c.responseCode; val text=c.inputStream.bufferedReader().readText(); if(code !in 200..299) throw Exception("HTTP $code"); val j=JSONObject(text); userId=j.getString("User").let{JSONObject(it).getString("Id")}; token=j.getString("AccessToken"); runOnUiThread{showHome()}; } catch(e:Exception){runOnUiThread{button.isEnabled=true;toast("连接失败：${e.message}")}} } }

    private fun conn(url:String, method:String, auth:String):HttpURLConnection { return URL(url).openConnection().apply{requestMethod=method; connectTimeout=15000; readTimeout=20000; setRequestProperty("X-Emby-Authorization",auth); setRequestProperty("Accept","application/json") } as HttpURLConnection }

    private fun showHome(){ root=base(); root.addView(tv("Qvey Player",28f)); root.addView(tv("媒体库",22f)); val status=tv("正在读取 Emby 媒体库…",14f); root.addView(status); setContentView(root); exec.execute{try{val c=conn("$server/Users/$userId/Views?api_key=${enc(token)}","GET", "MediaBrowser Client=Qvey Player, Device=Android, DeviceId=qvey, Version=2.6.0"); val j=JSONObject(c.inputStream.bufferedReader().readText()); val arr=j.getJSONArray("Items"); runOnUiThread{status.text="选择媒体库"; for(i in 0 until arr.length()){val x=arr.getJSONObject(i); val b=btn(x.optString("Name","媒体库")); root.addView(b); b.setOnClickListener{loadItems(x.getString("Id"))}}}}catch(e:Exception){runOnUiThread{status.text="读取失败：${e.message}"}}}}

    private fun loadItems(parent:String){ val r=base(); r.addView(tv("← 媒体库",24f)); val status=tv("加载中…",14f); r.addView(status); setContentView(r); exec.execute{try{val url="$server/Users/$userId/Items?ParentId=$parent&Recursive=true&IncludeItemTypes=Movie,Series&Fields=Overview,RunTimeTicks&Limit=100&api_key=${enc(token)}"; val c=conn(url,"GET","MediaBrowser Client=Qvey Player, Device=Android, DeviceId=qvey, Version=2.6.0"); val a=JSONObject(c.inputStream.bufferedReader().readText()).getJSONArray("Items"); runOnUiThread{status.text="共 ${a.length()} 项"; for(i in 0 until a.length()){val x=a.getJSONObject(i); val b=btn(x.optString("Name","未知")); r.addView(b); b.setOnClickListener{play(x.getString("Id"),x.optString("Name","播放"))}}}}catch(e:Exception){runOnUiThread{status.text="读取失败：${e.message}"}}}}

    private fun play(itemId:String,title:String){ val layout=FrameLayout(this); layout.setBackgroundColor(0xFF000000.toInt()); val pv=PlayerView(this); pv.useController=true; layout.addView(pv,FrameLayout.LayoutParams(-1,-1)); setContentView(layout); player?.release(); player=ExoPlayer.Builder(this).build().also{pv.player=it; val url="$server/Videos/$itemId/stream?static=true&api_key=${enc(token)}"; it.setMediaItem(MediaItem.fromUri(url)); it.prepare(); it.playWhenReady=true} }
    private fun enc(s:String)=URLEncoder.encode(s,"UTF-8")
    private fun toast(s:String)=Toast.makeText(this,s,Toast.LENGTH_LONG).show()
}
