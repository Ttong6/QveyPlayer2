package com.qvey.player.ui

import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.grid.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.animation.togetherWith
import androidx.compose.animation.Crossfade
import androidx.compose.animation.core.tween
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.platform.LocalConfiguration
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import coil3.compose.AsyncImage
import com.qvey.player.data.*
import com.qvey.player.player.PlayerScreen
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class MainViewModel(private val store: SessionStore) : ViewModel() {
    var session by mutableStateOf(store.load()); private set
    var libraries by mutableStateOf<List<Library>>(emptyList()); private set
    var items by mutableStateOf<List<EmbyItem>>(emptyList()); private set
    var continueItems by mutableStateOf<List<EmbyItem>>(emptyList()); private set
    var selected by mutableStateOf<EmbyItem?>(null); private set
    var children by mutableStateOf<List<EmbyItem>>(emptyList()); private set
    var playback by mutableStateOf<PlaybackSource?>(null); private set
    var loading by mutableStateOf(false); private set
    var error by mutableStateOf<String?>(null); private set
    var favoriteIds by mutableStateOf<Set<String>>(emptySet()); private set
    var query by mutableStateOf(""); var tab by mutableIntStateOf(0)
    init { if (session != null) refresh() }
    fun login(server:String,user:String,pass:String)=viewModelScope.launch{loading=true;error=null;runCatching{withContext(Dispatchers.IO){EmbyAuth.login(server,user,pass)}}.onSuccess{session=it;store.save(it);refresh()}.onFailure{error=it.message?:"登录失败"};loading=false}
    fun logout(){store.clear();session=null;items=emptyList();libraries=emptyList();continueItems=emptyList();selected=null;playback=null}
    fun refresh()=viewModelScope.launch{session?.let{s->loading=true;runCatching{withContext(Dispatchers.IO){val c=EmbyClient(s);Triple(c.libraries(),c.items(limit=120),c.items(limit=120))}}.onSuccess{libraries=it.first;items=it.second;continueItems=it.third.filter{m->(m.userData?.playbackPositionTicks?:0)>0&&!m.userData!!.played}}.onFailure{error=it.message};loading=false}}
    fun search(q:String){query=q;if(q.isBlank()){refresh();return};viewModelScope.launch{session?.let{s->loading=true;runCatching{items=withContext(Dispatchers.IO){EmbyClient(s).items(query=q,limit=120)}}.onFailure{error=it.message};loading=false}}}
    fun open(item:EmbyItem)=viewModelScope.launch{selected=item;children=emptyList();playback=null;loading=true;runCatching{withContext(Dispatchers.IO){val c=EmbyClient(session!!);if(item.type=="Movie"||item.type=="Video"||item.type=="Episode")null else c.children(item.id)}}.onSuccess{children=it?:emptyList()}.onFailure{error=it.message};loading=false}
    fun toggleFavorite(item:EmbyItem)=viewModelScope.launch{session?.let{s->val next=item.id !in favoriteIds;runCatching{withContext(Dispatchers.IO){EmbyClient(s).setFavorite(item.id,next)}}.onSuccess{favoriteIds=if(next)favoriteIds+item.id else favoriteIds-item.id}}}
    fun play(item:EmbyItem)=viewModelScope.launch{loading=true;runCatching{playback=withContext(Dispatchers.IO){EmbyClient(session!!).playback(item.id)};selected=item}.onFailure{error=it.message};loading=false}
    fun nextEpisode():EmbyItem?=selected?.let{s->runCatching{if(s.type=="Episode")EmbyClient(session!!).nextEpisode(s)else null}.getOrNull()}
    fun back(){selected=null;children=emptyList();playback=null}
}

@Composable
fun App(vm:MainViewModel){
    QveyTheme {
        AnimatedContent(
            targetState = Triple(vm.session != null, vm.selected?.id, vm.playback?.url),
            transitionSpec = { fadeIn(tween(180)) togetherWith fadeOut(tween(120)) },
            label = "qvey-screen-transition"
        ) { state ->
            when {
                state.third != null && vm.playback != null && vm.selected != null -> PlayerScreen(vm.session!!,vm.selected!!,vm.playback!!,vm::back,{vm.nextEpisode()?.let{vm.play(it)}})
                state.first && state.second != null && vm.selected != null -> DetailScreen(vm,vm.selected!!)
                state.first -> Home(vm)
                else -> LoginScreen(vm)
            }
        }
    }
}

@Composable private fun LoginScreen(vm:MainViewModel){
    Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color(0xFF0A1220),QveyColors.Background)))){
        Box(Modifier.fillMaxSize().background(Brush.radialGradient(listOf(QveyColors.AccentSoft,Color.Transparent),radius=850f)))
        Column(Modifier.fillMaxWidth().padding(28.dp).align(Alignment.Center).widthIn(max=520.dp),horizontalAlignment=Alignment.CenterHorizontally){
            BrandMark(large=true);Spacer(Modifier.height(14.dp));Text("你的 Emby 影音空间",style=MaterialTheme.typography.headlineMedium,fontWeight=FontWeight.Bold);Text("轻盈、沉浸、专注于播放",color=QveyColors.TextMuted);Spacer(Modifier.height(28.dp))
            Column(Modifier.qveyGlass().padding(20.dp),verticalArrangement=Arrangement.spacedBy(12.dp)){
                var server by remember{mutableStateOf("http://192.168.1.10:8096")};var user by remember{mutableStateOf("")};var pass by remember{mutableStateOf("")}
                OutlinedTextField(server,{server=it},label={Text("服务器地址")},singleLine=true,modifier=Modifier.fillMaxWidth())
                OutlinedTextField(user,{user=it},label={Text("用户名")},singleLine=true,modifier=Modifier.fillMaxWidth())
                OutlinedTextField(pass,{pass=it},label={Text("密码")},singleLine=true,modifier=Modifier.fillMaxWidth())
                Button({vm.login(server,user,pass)},enabled=!vm.loading,modifier=Modifier.fillMaxWidth().height(54.dp),shape=QveyShapes.medium){Text(if(vm.loading)"正在连接…" else "连接服务器")}
            }
            vm.error?.let{Spacer(Modifier.height(12.dp));Text(it,color=MaterialTheme.colorScheme.error)}
        }
    }
}

@Composable private fun BrandMark(large:Boolean=false){Row(verticalAlignment=Alignment.CenterVertically,horizontalArrangement=Arrangement.spacedBy(10.dp)){Box(Modifier.size(if(large)54.dp else 36.dp).shadow(12.dp,QveyColors.Accent,QveyShapes.medium).background(Brush.linearGradient(listOf(QveyColors.AccentStrong,QveyColors.Accent)),QveyShapes.medium),contentAlignment=Alignment.Center){Icon(Icons.Default.PlayArrow,null,tint=Color.White,modifier=Modifier.size(if(large)34.dp else 23.dp))};Text("Qvey Player",style=if(large)MaterialTheme.typography.headlineMedium else MaterialTheme.typography.titleLarge,fontWeight=FontWeight.Bold)}}

@Composable private fun Home(vm:MainViewModel){
    Scaffold(containerColor=QveyColors.Background,bottomBar={QveyNav(vm)}){pad->Column(Modifier.fillMaxSize().padding(pad)){
        TopBar(vm);when(vm.tab){0->HomeContent(vm);1->SearchContent(vm);2->LibraryContent(vm);else->SettingsContent(vm)}}}
}

@Composable private fun TopBar(vm:MainViewModel){Row(Modifier.fillMaxWidth().padding(horizontal=QveyDimens.Page,vertical=14.dp),verticalAlignment=Alignment.CenterVertically){BrandMark();Spacer(Modifier.width(16.dp));Column(Modifier.weight(1f)){Text("欢迎回来",style=MaterialTheme.typography.titleMedium,fontWeight=FontWeight.SemiBold);Text(vm.session?.serverName.orEmpty(),color=QveyColors.TextDim,style=MaterialTheme.typography.labelSmall)};if(vm.loading)CircularProgressIndicator(Modifier.size(20.dp),strokeWidth=2.dp);IconButton({vm.refresh()}){Icon(Icons.Default.Refresh,"刷新",tint=QveyColors.TextMuted)}}}

@Composable private fun QveyNav(vm:MainViewModel){NavigationBar(containerColor=QveyColors.Surface.copy(alpha=.96f),tonalElevation=0.dp){listOf(Icons.Default.Home to "首页",Icons.Default.Search to "搜索",Icons.Default.CollectionsBookmark to "媒体库",Icons.Default.Settings to "设置").forEachIndexed{i,(icon,label)->NavigationBarItem(selected=vm.tab==i,onClick={vm.tab=i},icon={Icon(icon,label,null)},label={Text(label)},colors=NavigationBarItemDefaults.colors(selectedIconColor=QveyColors.Accent,selectedTextColor=QveyColors.Accent,indicatorColor=QveyColors.AccentSoft,unselectedIconColor=QveyColors.TextDim,unselectedTextColor=QveyColors.TextDim))}}}

@Composable private fun HomeContent(vm:MainViewModel){
    val configuration = LocalConfiguration.current
    val compact = configuration.screenWidthDp < 600
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())){
        val hero=vm.items.firstOrNull()
        hero?.let{HeroCard(vm,it, compact)}
        if(vm.continueItems.isNotEmpty()){SectionHeader("继续观看","接着上次的进度继续");ItemRow(vm,vm.continueItems)}
        SectionHeader("最近添加","来自 Emby 媒体库的最新内容");ItemGrid(vm,vm.items)
        Spacer(Modifier.height(if(compact) 18.dp else 28.dp))
    }
}

@Composable private fun HeroCard(vm:MainViewModel,item:EmbyItem, compact:Boolean){
    val heroHeight = if(compact) 330.dp else 430.dp
    Box(Modifier.padding(horizontal=QveyDimens.Page,vertical=8.dp).fillMaxWidth().height(heroHeight).clip(QveyShapes.extraLarge).qveyInteractive()){
    val heroUrl = vm.session?.let { EmbyClient(it).imageUrl(item, "Backdrop", 1600) }
    Crossfade(targetState = heroUrl, animationSpec = tween(QveyMotion.Emphasis), label = "qvey-hero-image") { url ->
        QveyAmbientImage(Modifier.fillMaxSize()) {
            if (url != null) AsyncImage(url, item.name, Modifier.fillMaxSize(), contentScale = ContentScale.Crop) else QveyShimmer(Modifier.fillMaxSize())
        }
    }
    Box(Modifier.fillMaxSize().background(Brush.horizontalGradient(listOf(Color.Black.copy(.92f),Color.Black.copy(.18f),Color.Transparent))))
    Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color.Transparent,Color.Black.copy(.72f)))))
    Column(Modifier.align(Alignment.BottomStart).padding(if(compact) 20.dp else 28.dp).widthIn(max=620.dp)){Text("精选推荐",color=QveyColors.Accent,fontWeight=FontWeight.Bold);Text(item.name,style=if(compact) MaterialTheme.typography.headlineMedium else MaterialTheme.typography.headlineLarge,fontWeight=FontWeight.ExtraBold);Row(horizontalArrangement=Arrangement.spacedBy(8.dp)){item.productionYear?.let{MetaPill(it.toString())};item.officialRating?.let{MetaPill(it)};item.communityRating?.let{MetaPill("★ %.1f".format(it))}};Spacer(Modifier.height(14.dp));item.overview?.let{Text(it,maxLines=2,color=Color.White.copy(.78f),style=MaterialTheme.typography.bodyMedium)};Spacer(Modifier.height(14.dp));Row(horizontalArrangement=Arrangement.spacedBy(10.dp)){Button({vm.play(item)},shape=QveyShapes.medium){Icon(Icons.Default.PlayArrow,null);Spacer(Modifier.width(6.dp));Text("立即播放")};OutlinedButton({vm.open(item)},shape=QveyShapes.medium){Text("查看详情")}}}
}}

@Composable private fun MetaPill(text:String){Surface(color=Color.White.copy(.12f),shape=QveyDimens.ChipRadius.let{RoundedCornerShape(it)},tonalElevation=0.dp){Text(text,color=Color.White,modifier=Modifier.padding(horizontal=9.dp,vertical=5.dp),style=MaterialTheme.typography.labelSmall)}}
@Composable private fun SectionHeader(title:String,subtitle:String?=null){Row(Modifier.fillMaxWidth().padding(horizontal=QveyDimens.Section,vertical=10.dp),verticalAlignment=Alignment.Bottom){Column(Modifier.weight(1f)){Text(title,style=MaterialTheme.typography.titleLarge,fontWeight=FontWeight.Bold);subtitle?.let{Text(it,color=QveyColors.TextDim,style=MaterialTheme.typography.labelSmall)}};Text("›",color=QveyColors.TextDim,style=MaterialTheme.typography.headlineSmall)}}
@Composable private fun SearchContent(vm:MainViewModel){Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())){var q by remember{mutableStateOf(vm.query)};OutlinedTextField(q,{q=it;vm.search(it)},modifier=Modifier.fillMaxWidth().padding(horizontal=QveyDimens.Page,vertical=8.dp),placeholder={Text("搜索电影、剧集、演员…")},leadingIcon={Icon(Icons.Default.Search,null)},singleLine=true,shape=QveyShapes.medium);SectionHeader(if(q.isBlank())"全部媒体":"搜索结果");ItemGrid(vm,vm.items)}}
@Composable private fun LibraryContent(vm:MainViewModel){Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())){SectionHeader("媒体库","按 Emby 媒体库浏览");LazyRow(contentPadding=PaddingValues(horizontal=QveyDimens.Page),horizontalArrangement=Arrangement.spacedBy(8.dp)){items(vm.libraries){lib->FilterChip(selected=false,onClick={vm.search(lib.name)},label={Text(lib.name)},shape=QveyDimens.ChipRadius.let{RoundedCornerShape(it)})}};Spacer(Modifier.height(8.dp));ItemGrid(vm,vm.items)}}
@Composable private fun SettingsContent(vm:MainViewModel){Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(QveyDimens.Page),verticalArrangement=Arrangement.spacedBy(12.dp)){SectionHeader("设置","Qvey Player 2.5.0 · Native Android Polish");SettingCard(Icons.Default.Dns,"服务器",vm.session?.serverUrl.orEmpty());SettingCard(Icons.Default.PlayCircle,"播放引擎","AndroidX Media3 / ExoPlayer 1.11.1");SettingCard(Icons.Default.Speed,"播放模式","Direct Play → Direct Stream → Transcode 自动回退");SettingCard(Icons.Default.Palette,"视觉系统","深色玻璃层级、统一圆角、蓝色强调色");Spacer(Modifier.height(8.dp));OutlinedButton({vm.logout()},modifier=Modifier.fillMaxWidth().height(50.dp),shape=QveyShapes.medium){Text("退出登录")}}}
@Composable private fun SettingCard(icon:androidx.compose.ui.graphics.vector.ImageVector,title:String,value:String){Row(Modifier.fillMaxWidth().qveyGlass().padding(16.dp),verticalAlignment=Alignment.CenterVertically){Icon(icon,null,tint=QveyColors.Accent);Spacer(Modifier.width(14.dp));Column{Text(title,fontWeight=FontWeight.SemiBold);Text(value,color=QveyColors.TextDim,style=MaterialTheme.typography.bodySmall)}}}

@Composable private fun DetailScreen(vm:MainViewModel,item:EmbyItem){val compact=LocalConfiguration.current.screenWidthDp<600;Column(Modifier.fillMaxSize().background(QveyColors.Background).verticalScroll(rememberScrollState())){Box(Modifier.fillMaxWidth().height(if(compact) 320.dp else 440.dp)){AsyncImage(vm.session?.let{EmbyClient(it).imageUrl(item,"Backdrop",1600)},null,Modifier.fillMaxSize(),contentScale=ContentScale.Crop);Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color.Black.copy(.08f),QveyColors.Background.copy(.98f)))));IconButton({vm.back()},Modifier.align(Alignment.TopStart).padding(8.dp)){Icon(Icons.Default.ArrowBack,"返回",tint=Color.White)}};Column(Modifier.padding(QveyDimens.Page)){Text(item.name,style=if(compact) MaterialTheme.typography.headlineMedium else MaterialTheme.typography.headlineLarge,fontWeight=FontWeight.ExtraBold);Row(horizontalArrangement=Arrangement.spacedBy(8.dp),modifier=Modifier.padding(top=8.dp)){item.productionYear?.let{MetaPill(it.toString())};item.officialRating?.let{MetaPill(it)};item.communityRating?.let{MetaPill("★ %.1f".format(it))}};Spacer(Modifier.height(16.dp));Row(horizontalArrangement=Arrangement.spacedBy(10.dp)){Button({if(item.type=="Series"&&vm.children.isNotEmpty())vm.play(vm.children.first())else vm.play(item)},shape=QveyShapes.medium){Icon(Icons.Default.PlayArrow,null);Spacer(Modifier.width(6.dp));Text(if(item.userData?.playbackPositionTicks?:0>0)"继续播放" else "播放")};OutlinedButton({vm.toggleFavorite(item)},shape=QveyShapes.medium){Icon(if(item.id in vm.favoriteIds)Icons.Default.Bookmark else Icons.Default.BookmarkBorder,null);Spacer(Modifier.width(5.dp));Text(if(item.id in vm.favoriteIds)"已收藏" else "收藏")}};item.overview?.let{Spacer(Modifier.height(20.dp));Text(it,color=QveyColors.TextMuted,lineHeight=MaterialTheme.typography.bodyLarge.lineHeight)};if(vm.children.isNotEmpty()){SectionHeader("剧集","共 ${vm.children.size} 集");vm.children.forEachIndexed{i,e->EpisodeCard(vm,i,e)}};Spacer(Modifier.height(24.dp))}}}
@Composable private fun EpisodeCard(vm:MainViewModel,index:Int,item:EmbyItem){Row(Modifier.fillMaxWidth().qveyGlass().clickable{vm.play(item)}.padding(10.dp),verticalAlignment=Alignment.CenterVertically){AsyncImage(vm.session?.let{EmbyClient(it).imageUrl(item)},item.name,Modifier.size(82.dp,52.dp).clip(QveyShapes.small),contentScale=ContentScale.Crop);Spacer(Modifier.width(12.dp));Column(Modifier.weight(1f)){Text("${index+1}. ${item.name}",fontWeight=FontWeight.SemiBold,maxLines=1);Text(item.overview.orEmpty(),maxLines=2,color=QveyColors.TextDim,style=MaterialTheme.typography.bodySmall)};Icon(Icons.Default.PlayArrow,null,tint=QveyColors.Accent)}}

@Composable private fun ItemRow(vm:MainViewModel,list:List<EmbyItem>){LazyRow(contentPadding=PaddingValues(horizontal=QveyDimens.Page),horizontalArrangement=Arrangement.spacedBy(12.dp)){items(list,key={it.id}){PosterCard(vm,it,156.dp)}}}
@Composable private fun ItemGrid(vm:MainViewModel,list:List<EmbyItem>){LazyVerticalGrid(columns=GridCells.Adaptive(142.dp),modifier=Modifier.heightIn(min=120.dp,max=6000.dp),contentPadding=PaddingValues(horizontal=QveyDimens.Page,vertical=8.dp),horizontalArrangement=Arrangement.spacedBy(12.dp),verticalArrangement=Arrangement.spacedBy(18.dp),userScrollEnabled=false){items(list,key={it.id}){PosterCard(vm,it,142.dp)}}}
@Composable private fun PosterCard(vm:MainViewModel,item:EmbyItem,width:androidx.compose.ui.unit.Dp){
    Column(Modifier.width(width)){
        QveyPressable(onClick={vm.open(item)},modifier=Modifier.fillMaxWidth()){
            Box(Modifier.fillMaxWidth().aspectRatio(.67f).clip(QveyShapes.medium).qveyInteractive()){
                Box(Modifier.fillMaxSize().background(QveyColors.SurfaceRaised))
                AsyncImage(vm.session?.let{EmbyClient(it).imageUrl(item)},item.name,Modifier.fillMaxSize(),contentScale=ContentScale.Crop)
                Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color.Transparent,Color.Black.copy(.28f)))))
                if(item.userData?.playbackPositionTicks ?: 0L > 0L && item.userData?.played != true){
                    Box(Modifier.align(Alignment.BottomStart).fillMaxWidth().height(4.dp).background(Color.Black.copy(.55f)))
                    Box(Modifier.align(Alignment.BottomStart).fillMaxWidth(.42f).height(4.dp).background(QveyColors.Accent))
                }
                if(item.userData?.played==true)Surface(Modifier.align(Alignment.TopEnd).padding(7.dp),color=QveyColors.Accent,shape=QveyShapes.small){Icon(Icons.Default.Check,null,tint=Color.White,modifier=Modifier.padding(4.dp).size(15.dp))}
                item.communityRating?.let{MetaPill("★ %.1f".format(it))}
            }
        }
        Spacer(Modifier.height(8.dp)); Text(item.name,maxLines=2,fontWeight=FontWeight.SemiBold)
        Row(horizontalArrangement=Arrangement.spacedBy(6.dp)){item.productionYear?.let{Text("$it",color=QveyColors.TextDim,style=MaterialTheme.typography.labelSmall)};item.officialRating?.let{Text(it,color=QveyColors.TextDim,style=MaterialTheme.typography.labelSmall)}}
    }
}
