package com.qvey.player.player

import android.Manifest
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.content.pm.PackageManager
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.media3.session.MediaSession
import androidx.media3.session.MediaStyleNotificationHelper
import com.qvey.player.R

object QveyNowPlayingNotification {
    private const val CHANNEL = "qvey_playback"
    private const val ID = 1801

    fun show(context: Context, session: MediaSession, title: String, playing: Boolean) {
        if (android.os.Build.VERSION.SDK_INT >= 33 && context.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) return
        val nm = context.getSystemService(NotificationManager::class.java)
        if (android.os.Build.VERSION.SDK_INT >= 26) {
            nm.createNotificationChannel(NotificationChannel(CHANNEL, "Qvey Player 播放控制", NotificationManager.IMPORTANCE_LOW).apply { description = "播放中的媒体控制" })
        }
        val builder = NotificationCompat.Builder(context, CHANNEL)
            .setSmallIcon(android.R.drawable.ic_media_play)
            .setContentTitle(title)
            .setContentText(if (playing) "正在播放" else "已暂停")
            .setOngoing(playing)
            .setSilent(true)
            .setCategory(NotificationCompat.CATEGORY_TRANSPORT)
            .setVisibility(NotificationCompat.VISIBILITY_PUBLIC)
            .setStyle(MediaStyleNotificationHelper.MediaStyle(session))
        NotificationManagerCompat.from(context).notify(ID, builder.build())
    }

    fun cancel(context: Context) { NotificationManagerCompat.from(context).cancel(ID) }
}
