package com.qvey.player.data

import android.content.Context
import org.json.JSONObject

class SessionStore(context: Context) {
 private val p=context.getSharedPreferences("emby_session",Context.MODE_PRIVATE)
 fun save(s:EmbySession){p.edit().putString("data",JSONObject().apply{put("userId",s.userId);put("token",s.token);put("serverUrl",s.serverUrl);put("serverName",s.serverName)}.toString()).apply()}
 fun load():EmbySession?=runCatching{val o=JSONObject(p.getString("data",null)?:return null);EmbySession(o.getString("userId"),o.getString("token"),o.getString("serverUrl"),o.getString("serverName"))}.getOrNull()
 fun clear(){p.edit().clear().apply()}
 fun getFloat(key:String, default:Float)=p.getFloat(key,default)
 fun putFloat(key:String,value:Float){p.edit().putFloat(key,value).apply()}
 fun getInt(key:String, default:Int)=p.getInt(key,default)
 fun putInt(key:String,value:Int){p.edit().putInt(key,value).apply()}
 fun getBoolean(key:String, default:Boolean)=p.getBoolean(key,default)
 fun putBoolean(key:String,value:Boolean){p.edit().putBoolean(key,value).apply()}
 fun getIntForItem(itemId:String,key:String,default:Int=-1)=p.getInt("$key:$itemId",default)
 fun putIntForItem(itemId:String,key:String,value:Int){p.edit().putInt("$key:$itemId",value).apply()}
 fun getBooleanForItem(itemId:String,key:String,default:Boolean=false)=p.getBoolean("$key:$itemId",default)
 fun putBooleanForItem(itemId:String,key:String,value:Boolean){p.edit().putBoolean("$key:$itemId",value).apply()}
}
