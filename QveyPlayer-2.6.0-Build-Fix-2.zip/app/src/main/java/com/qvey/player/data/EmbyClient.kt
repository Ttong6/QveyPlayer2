package com.qvey.player.data

import okhttp3.*
import org.json.JSONArray
import org.json.JSONObject
import java.util.UUID

class EmbyClient(private val session:EmbySession){
 private val http=OkHttpClient()
 private fun api(path:String)=session.serverUrl.trimEnd('/')+"/emby"+path
 private fun auth():String="Emby UserId=\"${session.userId}\", Client=\"Android\", Device=\"Qvey Player\", DeviceId=\"$deviceId\", Version=\"1.6.0\""
 private fun req(path:String,method:String="GET",body:String?=null)=Request.Builder().url(api(path)).header("X-Emby-Token",session.token).header("X-Emby-Authorization",auth()).apply{if(method=="POST")post((body?:"{}").toRequestBody("application/json".toMediaType()))}.build()
 private fun json(path:String,method:String="GET",body:String?=null):JSONObject=http.newCall(req(path,method,body)).execute().use{r->if(!r.isSuccessful)error("Emby HTTP ${r.code}");JSONObject(r.body?.string()?:("{}"))}
 fun libraries():List<Library>{val a=json("/Users/${session.userId}/Views").optJSONArray("Items")?:JSONArray();return buildList{for(i in 0 until a.length()){val o=a.getJSONObject(i);add(Library(o.getString("Id"),o.optString("Name"),o.optString("CollectionType").ifBlank{null},o.optString("ImageTags").ifBlank{null}))}}}
 fun items(parentId:String?=null,query:String?=null,limit:Int=100):List<EmbyItem>{
  val p=mutableListOf("Recursive=true","IncludeItemTypes=Movie,Series,Episode,Video","SortBy=SortName","SortOrder=Ascending","Limit=$limit","Fields=Overview,PrimaryImageAspectRatio,UserData,RunTimeTicks,SeriesId,ParentId,ProductionYear,CommunityRating,OfficialRating,SeriesName,Chapters,MediaStreams")
  if(parentId!=null)p.add("ParentId=$parentId");if(!query.isNullOrBlank())p.add("SearchTerm=${java.net.URLEncoder.encode(query,"UTF-8")}")
  val a=json("/Users/${session.userId}/Items?${p.joinToString("&")}").optJSONArray("Items")?:JSONArray();return buildList{for(i in 0 until a.length())add(parse(a.getJSONObject(i)))}
 }
 fun children(parentId:String):List<EmbyItem> = items(parentId=parentId, limit=200)
 fun playback(itemId:String):PlaybackSource{
  val body=JSONObject().apply{put("UserId",session.userId);put("EnableDirectPlay",true);put("EnableDirectStream",true);put("EnableTranscoding",true);put("AutoOpenLiveStream",true);put("DeviceProfile",JSONObject().apply{put("Name","Qvey Player Android");put("MaxStreamingBitrate",120_000_000)})}.toString()
  val root=json("/Items/$itemId/PlaybackInfo?UserId=${session.userId}","POST",body);val a=root.optJSONArray("MediaSources")?:JSONArray();if(a.length()==0)error("没有可播放媒体源")
  val candidates=(0 until a.length()).map{a.getJSONObject(it)};val s=candidates.firstOrNull{it.optBoolean("SupportsDirectPlay")&&it.optString("DirectPlayUrl").isNotBlank()}?:candidates.firstOrNull{it.optString("DirectStreamUrl").isNotBlank()}?:candidates.first()
  val direct=s.optString("DirectPlayUrl").ifBlank{null};val stream=s.optString("DirectStreamUrl").ifBlank{null};val trans=s.optString("TranscodingUrl").ifBlank{null};val raw=direct?:stream?:trans?:error("Emby 未返回播放 URL")
  val full=if(raw.startsWith("http"))raw else session.serverUrl.trimEnd('/')+raw+(if(raw.contains("?"))"&api_key=${session.token}" else "?api_key=${session.token}")
  val method=when{direct!=null->"DirectPlay";stream!=null->"DirectStream";else->"Transcode"};val v=s.optJSONArray("MediaStreams")?.let{arr->(0 until arr.length()).map{arr.getJSONObject(it)}.firstOrNull{it.optString("Type")=="Video"}?.optString("Codec")};val ac=s.optJSONArray("MediaStreams")?.let{arr->(0 until arr.length()).map{arr.getJSONObject(it)}.firstOrNull{it.optString("Type")=="Audio"}?.optString("Codec")}
  val streams=s.optJSONArray("MediaStreams")
  val parsedStreams=streams?.let{arr->(0 until arr.length()).map{j->val x=arr.getJSONObject(j);MediaStream(x.optInt("Index"),x.optString("Type"),x.optString("Codec").ifBlank{null},x.optString("Language").ifBlank{null},x.optString("Title").ifBlank{null},x.optString("DisplayTitle").ifBlank{null},x.optBoolean("IsDefault"),x.optBoolean("IsForced"))}} ?: emptyList()
  val vs=streams?.let{arr->(0 until arr.length()).map{arr.getJSONObject(it)}.firstOrNull{it.optString("Type")=="Video"}}
  val as_=streams?.let{arr->(0 until arr.length()).map{arr.getJSONObject(it)}.firstOrNull{it.optString("Type")=="Audio"}}
  val ss=streams?.let{arr->(0 until arr.length()).map{arr.getJSONObject(it)}.firstOrNull{it.optString("Type")=="Subtitle" && !it.optBoolean("IsForced")}}
  val chapters=root.optJSONArray("Chapters")?.let{arr->(0 until arr.length()).map{j->val x=arr.getJSONObject(j);Chapter(x.optLong("StartPositionTicks"),x.optLong("EndPositionTicks"),x.optString("Name").ifBlank{null})}} ?: emptyList()
  return PlaybackSource(s.optString("Id"),full,s.optString("MimeType").ifBlank{null},root.optString("PlaySessionId").ifBlank{null},method,v,ac,vs?.optInt("Height")?.takeIf{it>0},vs?.optInt("Width")?.takeIf{it>0},as_?.optInt("Channels")?.takeIf{it>0},as_?.optInt("Index")?.takeIf{it>=0},ss?.optInt("Index")?.takeIf{it>=0},parsedStreams,chapters)
 }
 fun imageUrl(item:EmbyItem,type:String="Primary",width:Int=800):String=api("/Items/${item.id}/Images/$type?MaxWidth=$width")+"&api_key=${session.token}"
 fun reportStart(item:EmbyItem,source:PlaybackSource,positionMs:Long=0,paused:Boolean=false){report(item,source,positionMs,paused,"/Sessions/Playing")}
 fun reportProgress(item:EmbyItem,source:PlaybackSource,positionMs:Long,paused:Boolean){report(item,source,positionMs,paused,"/Sessions/Playing/Progress")}
 fun reportStopped(item:EmbyItem,source:PlaybackSource,positionMs:Long){report(item,source,positionMs,false,"/Sessions/Playing/Stopped")}
 private fun report(item:EmbyItem,source:PlaybackSource,posMs:Long,paused:Boolean,path:String){val body=JSONObject().apply{put("ItemId",item.id);put("MediaSourceId",source.mediaSourceId);put("PlaySessionId",source.playSessionId?:"");put("PositionTicks",posMs*10_000);put("IsPaused",paused);put("IsMuted",false);put("CanSeek",true);put("PlayMethod",source.playMethod);put("QueueableMediaTypes",JSONArray().put("Video"));put("PlaybackRate",1.0)}.toString();try{http.newCall(req(path,"POST",body)).execute().close()}catch(_:Exception){}}
 fun setFavorite(itemId:String,favorite:Boolean){val path="/Users/${session.userId}/FavoriteItems/$itemId";http.newCall(req(path,if(favorite)"POST" else "DELETE")).execute().close()}
 fun nextEpisode(item:EmbyItem):EmbyItem?{
  if(item.type!="Episode"||item.seriesId.isNullOrBlank())return null
  val list=items(parentId=item.seriesId,limit=500).filter{it.type=="Episode"}.sortedWith(compareBy<EmbyItem>{it.seasonNumber ?: Int.MAX_VALUE}.thenBy{it.episodeNumber ?: Int.MAX_VALUE}.thenBy{it.name}}
  val current=list.indexOfFirst{it.id==item.id}
  return if(current>=0) list.getOrNull(current+1) else null
 }
 fun markPlayed(itemId:String,played:Boolean=true){val path="/Users/${session.userId}/PlayedItems/$itemId";http.newCall(req(path,if(played)"POST" else "DELETE")).execute().close()}
 private fun parse(o:JSONObject)=EmbyItem(o.getString("Id"),o.optString("Name"),o.optString("Type"),o.optString("Overview").ifBlank{null},o.optJSONObject("ImageTags")?.optString("Primary").ifBlank{null},o.optLong("RunTimeTicks").takeIf{it>0},o.optJSONObject("UserData")?.let{UserData(it.optBoolean("Played"),it.optLong("PlaybackPositionTicks"),it.optDouble("PlayedPercentage").takeIf{p->!p.isNaN()},it.optBoolean("IsFavorite"))},o.optString("SeriesId").ifBlank{null},o.optString("ParentId").ifBlank{null},o.optInt("ProductionYear").takeIf{it>0},o.optDouble("CommunityRating").takeIf{!it.isNaN()},o.optString("OfficialRating").ifBlank{null},o.optString("SeriesName").ifBlank{null},o.optInt("ParentIndexNumber").takeIf{it>0},o.optInt("IndexNumber").takeIf{it>0})
 companion object{val deviceId=UUID.randomUUID().toString()}
}
object EmbyAuth{fun login(server:String,username:String,password:String):EmbySession{val base=server.trim().trimEnd('/');val http=OkHttpClient();val body=JSONObject().apply{put("Username",username);put("Pw",password)}.toString().toRequestBody("application/json".toMediaType());val auth="Emby UserId=\"\", Client=\"Android\", Device=\"Qvey Player\", DeviceId=\"${EmbyClient.deviceId}\", Version=\"1.6.0\"";val r=Request.Builder().url("$base/emby/Users/AuthenticateByName").post(body).header("X-Emby-Authorization",auth).build();return http.newCall(r).execute().use{if(!it.isSuccessful)error("登录失败：HTTP ${it.code}");val o=JSONObject(it.body!!.string());val u=o.getJSONObject("User");EmbySession(u.getString("Id"),o.getString("AccessToken"),base,u.optString("ServerName").ifBlank{"Emby"})}}}
