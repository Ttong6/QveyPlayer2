package com.qvey.player.player

import android.app.Activity
import android.app.PictureInPictureParams
import android.view.WindowManager
import android.view.View
import android.content.pm.ActivityInfo
import android.os.Build
import androidx.compose.foundation.background
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.activity.compose.BackHandler
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.common.Tracks
import androidx.media3.common.AudioAttributes
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.session.MediaSession
import androidx.media3.ui.AspectRatioFrameLayout
import androidx.media3.ui.compose.Player as Media3Player
import com.qvey.player.data.*
import com.qvey.player.ui.qveyHud
import com.qvey.player.ui.QveyGestureHud
import kotlinx.coroutines.delay

@Composable
fun PlayerScreen(session: EmbySession, item: EmbyItem, source: PlaybackSource, onBack: () -> Unit, onNext: (() -> Unit)? = null) {
    val context = LocalContext.current
    val activity = context as? Activity
    val prefs = remember(context) { SessionStore(context) }
    val client = remember(session) { EmbyClient(session) }
    var error by remember { mutableStateOf<String?>(null) }
    var panel by remember { mutableStateOf<String?>(null) }
    var tracks by remember { mutableStateOf<Tracks?>(null) }
    var controls by remember { mutableStateOf(true) }
    var position by remember { mutableLongStateOf(item.userData?.playbackPositionTicks?.div(10_000) ?: 0L) }
    var duration by remember { mutableLongStateOf(0L) }
    var speed by remember { mutableFloatStateOf(prefs.getFloat("speed", 1f)) }
    var aspect by remember { mutableIntStateOf(prefs.getInt("aspect", AspectRatioFrameLayout.RESIZE_MODE_FIT)) }
    var volume by remember { mutableFloatStateOf(prefs.getFloat("volume", 1f)) }
    var brightness by remember { mutableFloatStateOf(.7f) }
    var seekPreview by remember { mutableLongStateOf(-1L) }
    var gestureHint by remember { mutableStateOf<String?>(null) }
    var seekFeedback by remember { mutableStateOf<String?>(null) }
    var chapterDialog by remember { mutableStateOf(false) }
    var skipIntro by remember { mutableStateOf(prefs.getBoolean("skip_intro", false)) }
    var skipOutro by remember { mutableStateOf(prefs.getBoolean("skip_outro", false)) }
    var autoNext by remember { mutableStateOf(prefs.getBoolean("auto_next", true)) }
    var rememberAudio by remember { mutableStateOf(prefs.getBoolean("remember_audio", true)) }
    var rememberSubtitle by remember { mutableStateOf(prefs.getBoolean("remember_subtitle", true)) }
    var keepScreenOn by remember { mutableStateOf(prefs.getBoolean("keep_screen_on", true)) }
    var controlLock by remember { mutableStateOf(false) }
    var skippedChapterIds by remember { mutableStateOf(setOf<Int>()) }
    var systemBarsHidden by remember { mutableStateOf(true) }

    val player = remember(context, source.url) {
        ExoPlayer.Builder(context).build().apply {
            setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(C.USAGE_MEDIA)
                    .setContentType(C.AUDIO_CONTENT_TYPE_MOVIE)
                    .build(),
                true
            )
            setHandleAudioBecomingNoisy(true)
            setMediaItem(MediaItem.Builder().setUri(source.url).apply { source.mimeType?.let { setMimeType(it) } }.build())
            setPlaybackSpeed(speed)
            volume = volume
            prepare()
            seekTo(position)
            playWhenReady = true
        }
    }
    val mediaSession = remember(player) { MediaSession.Builder(context, player).setId("qvey-player").build() }

    DisposableEffect(player, mediaSession) {
        val listener = object : Player.Listener {
            override fun onPlayerError(e: PlaybackException) { error = e.message ?: "播放失败" }
            override fun onTracksChanged(t: Tracks) {
                tracks = t
                if (rememberAudio) {
                    val wanted = prefs.getIntForItem(item.id, "audio", -1)
                    if (wanted >= 0) applyStreamOverride(player, t, C.TRACK_TYPE_AUDIO, wanted)
                }
                if (rememberSubtitle) {
                    val wanted = prefs.getIntForItem(item.id, "subtitle", -1)
                    if (wanted >= 0) applyStreamOverride(player, t, C.TRACK_TYPE_TEXT, wanted)
                }
            }
            override fun onTimelineChanged(timeline: androidx.media3.common.Timeline, reason: Int) { duration = player.duration.coerceAtLeast(0L) }
            override fun onIsPlayingChanged(isPlaying: Boolean) { QveyNowPlayingNotification.show(context, mediaSession, item.name, isPlaying) }
            override fun onPlaybackStateChanged(state: Int) {
                duration = player.duration.coerceAtLeast(0L)
                if (state == Player.STATE_ENDED && autoNext && onNext != null) onNext()
            }
        }
        player.addListener(listener)
        onDispose {
            client.reportStopped(item, source, player.currentPosition)
            QveyNowPlayingNotification.cancel(context)
            player.removeListener(listener)
            player.release()
            mediaSession.release()
            activity?.window?.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
            activity?.requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
        }
    }

    BackHandler {
        if (panel != null) { panel = null }
        else if (chapterDialog) { chapterDialog = false }
        else onBack()
    }

    LaunchedEffect(systemBarsHidden, controls, controlLock) {
        val decor = activity?.window?.decorView ?: return@LaunchedEffect
        if (systemBarsHidden && !controls && !controlLock) {
            decor.systemUiVisibility = (View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                or View.SYSTEM_UI_FLAG_FULLSCREEN
                or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                or View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                or View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                or View.SYSTEM_UI_FLAG_LAYOUT_STABLE)
        } else {
            decor.systemUiVisibility = View.SYSTEM_UI_FLAG_LAYOUT_STABLE
        }
    }

    LaunchedEffect(player) {
        if (keepScreenOn) activity?.window?.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        else activity?.window?.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        activity?.requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
        activity?.window?.attributes = activity.window.attributes.apply { screenBrightness = brightness }
        client.reportStart(item, source, player.currentPosition, false)
        QveyNowPlayingNotification.show(context, mediaSession, item.name, true)
        while (true) {
            delay(500)
            position = player.currentPosition.coerceAtLeast(0L)
            duration = player.duration.coerceAtLeast(0L)
            if (player.isPlaying || player.currentPosition > 0) {
                client.reportProgress(item, source, player.currentPosition, !player.isPlaying)
            }

            val chapterIndex = source.chapters.indexOfLast { player.currentPosition >= it.startTicks / 10_000 }
            val chapter = source.chapters.getOrNull(chapterIndex)
            val name = chapter?.name?.lowercase().orEmpty()
            val intro = name.contains("intro") || name.contains("opening") || name.contains("片头") || name.contains("op")
            val outro = name.contains("outro") || name.contains("ending") || name.contains("片尾") || name.contains("ed")
            if (chapterIndex >= 0 && chapterIndex !in skippedChapterIds) {
                if ((intro && skipIntro) || (outro && skipOutro)) {
                    skippedChapterIds = skippedChapterIds + chapterIndex
                    val target = source.chapters.getOrNull(chapterIndex + 1)?.startTicks?.div(10_000)
                    if (target != null && target > player.currentPosition) player.seekTo(target)
                }
            }
        }
    }

    LaunchedEffect(controls) { if (controls) { delay(4000); controls = false; systemBarsHidden = true } }

    Box(
        Modifier.fillMaxSize().background(Color.Black)
            .pointerInput(controlLock) {
                if (controlLock) return@pointerInput
                detectHorizontalDragGestures(
                    onDragStart = { seekPreview = player.currentPosition; controls = true; systemBarsHidden = false },
                    onHorizontalDrag = { _, delta -> seekPreview = (seekPreview + (delta * 80).toLong()).coerceIn(0L, duration.coerceAtLeast(0L)); controls = true },
                    onDragEnd = { if (seekPreview >= 0) player.seekTo(seekPreview); seekPreview = -1L; systemBarsHidden = false }
                )
            }
            .pointerInput(controlLock) {
                if (controlLock) return@pointerInput
                detectVerticalDragGestures { change, delta ->
                    change.consume()
                    if (change.position.x < context.resources.displayMetrics.widthPixels / 2f) {
                        brightness = (brightness - delta / 900f).coerceIn(.05f, 1f)
                        activity?.window?.attributes = activity.window.attributes.apply { screenBrightness = brightness }
                        gestureHint = "亮度 ${"%.0f".format(brightness * 100)}%"
                    } else {
                        volume = (volume - delta / 900f).coerceIn(0f, 1f)
                        player.volume = volume
                        prefs.putFloat("volume", volume)
                        gestureHint = "音量 ${"%.0f".format(volume * 100)}%"
                    }
                    controls = true
                }
            }
            .pointerInput(controlLock) {
                detectTapGestures(onTap = { controls = !controls; systemBarsHidden = !controls }, onDoubleTap = { offset ->
                    systemBarsHidden = false
                    val delta = if (offset.x < context.resources.displayMetrics.widthPixels / 2f) -10_000L else 10_000L
                    player.seekTo((player.currentPosition + delta).coerceIn(0L, duration.coerceAtLeast(0L))); seekFeedback = if (delta < 0) "−10 秒" else "+10 秒"; controls = true
                })
            }
    ) {
        Media3Player(player = player, modifier = Modifier.fillMaxSize(), contentScale = aspect)

        AnimatedVisibility(
            visible = seekFeedback != null,
            enter = fadeIn(tween(120)) + scaleIn(tween(180), initialScale = .72f),
            exit = fadeOut(tween(140)) + scaleOut(tween(160), targetScale = .88f),
            modifier = Modifier.align(Alignment.Center)
        ) {
            Surface(color = Color.Black.copy(alpha = .72f), shape = MaterialTheme.shapes.extraLarge) {
                Text(seekFeedback.orEmpty(), color = Color.White, modifier = Modifier.padding(horizontal = 26.dp, vertical = 16.dp), style = MaterialTheme.typography.headlineSmall)
            }
            LaunchedEffect(seekFeedback) { delay(650); seekFeedback = null }
        }

        gestureHint?.let { hint ->
            LaunchedEffect(hint) { delay(900); gestureHint = null }
            val gestureIcon = when { hint.startsWith("亮度") -> Icons.Default.Brightness6; hint.startsWith("音量") -> Icons.Default.VolumeUp; else -> null }
            QveyGestureHud(hint, gestureIcon, Modifier.align(Alignment.Center))
        }
        if (seekPreview >= 0) {
            val previewProgress = if (duration > 0) seekPreview.toFloat() / duration.toFloat() else 0f
            Column(Modifier.align(Alignment.Center).qveyHud().padding(10.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                Box(Modifier.width(210.dp).height(118.dp).background(
                    Brush.linearGradient(listOf(Color(0xFF1A2434), Color(0xFF0C111A), Color(0xFF243653))),
                    MaterialTheme.shapes.large
                )) {
                    Text("时间预览", color = Color.White.copy(alpha = .62f), modifier = Modifier.align(Alignment.Center), style = MaterialTheme.typography.labelMedium)
                    Text("${(previewProgress * 100).toInt()}%", color = Color.White.copy(alpha = .45f), modifier = Modifier.align(Alignment.BottomEnd).padding(8.dp), style = MaterialTheme.typography.labelSmall)
                }
                Spacer(Modifier.height(8.dp))
                Text("${formatTime(seekPreview)} / ${formatTime(duration)}", color = Color.White, style = MaterialTheme.typography.titleMedium)
            }
        }

        if (controlLock) {
            IconButton(
                onClick = { controlLock = false; controls = true },
                modifier = Modifier.align(Alignment.TopEnd).padding(12.dp)
            ) { Icon(Icons.Default.Lock, "解锁控制", tint = Color.White) }
        }

        AnimatedVisibility(
            visible = controls && !controlLock,
            enter = fadeIn(tween(220)) + slideInVertically(tween(260), initialOffsetY = { -18 }),
            exit = fadeOut(tween(180)) + slideOutVertically(tween(220), targetOffsetY = { -18 })
        ) {
            Column(Modifier.fillMaxSize().padding(10.dp)) {
            Row(Modifier.fillMaxWidth().qveyHud().padding(horizontal = 6.dp, vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                IconButton(onBack) { Icon(Icons.Default.ArrowBack, "返回", tint = Color.White) }
                Column(Modifier.weight(1f)) {
                    Text(item.name, color = Color.White, maxLines = 1)
                    Text("${source.playMethod} · ${listOfNotNull(source.videoCodec, source.audioCodec).joinToString(" / ")}", color = Color.LightGray, style = MaterialTheme.typography.labelSmall)
                }
                IconButton({ panel = "tracks" }) { Icon(Icons.Default.Subtitles, "音轨字幕", tint = Color.White) }
                if (source.chapters.isNotEmpty()) IconButton({ chapterDialog = true }) { Icon(Icons.Default.List, "章节", tint = Color.White) }
                IconButton({ panel = "settings" }) { Icon(Icons.Default.Settings, "设置", tint = Color.White) }
                IconButton({ controlLock = !controlLock; controls = !controlLock }) { Icon(if (controlLock) Icons.Default.Lock else Icons.Default.LockOpen, "锁定", tint = Color.White) }
            }
            Spacer(Modifier.weight(1f))
            if (source.chapters.isNotEmpty()) {
                val currentChapter = source.chapters.indexOfLast { player.currentPosition >= it.startTicks / 10_000 }.coerceAtLeast(0)
                Text("${source.chapters.getOrNull(currentChapter)?.name ?: "章节"} · ${currentChapter + 1}/${source.chapters.size}", color = Color.White, modifier = Modifier.align(Alignment.CenterHorizontally))
            }
            Row(Modifier.fillMaxWidth().qveyHud().padding(horizontal = 10.dp, vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                Text(formatTime(position), color = Color.White, style = MaterialTheme.typography.labelSmall)
                Slider(value = position.toFloat().coerceIn(0f, duration.coerceAtLeast(1L).toFloat()), onValueChange = { seekPreview = it.toLong() }, onValueChangeFinished = { player.seekTo(seekPreview); position = seekPreview; seekPreview = -1L }, valueRange = 0f..duration.coerceAtLeast(1L).toFloat(), modifier = Modifier.weight(1f).padding(horizontal = 8.dp))
                Text(formatTime(duration), color = Color.White, style = MaterialTheme.typography.labelSmall)
            }
            Row(Modifier.fillMaxWidth().qveyHud().padding(vertical = 4.dp), horizontalArrangement = Arrangement.SpaceEvenly, verticalAlignment = Alignment.CenterVertically) {
                IconButton({ player.seekBack() }) { Icon(Icons.Default.Replay10, "后退", tint = Color.White) }
                IconButton({ if (player.isPlaying) player.pause() else player.play() }) { Icon(if (player.isPlaying) Icons.Default.Pause else Icons.Default.PlayArrow, "播放", tint = Color.White, modifier = Modifier.size(44.dp)) }
                IconButton({ player.seekForward() }) { Icon(Icons.Default.Forward30, "前进", tint = Color.White) }
                if (onNext != null) IconButton(onNext) { Icon(Icons.Default.SkipNext, "下一集", tint = Color.White) }
                IconButton({ enterPip(activity) }) { Icon(Icons.Default.PictureInPictureAlt, "画中画", tint = Color.White) }
            }
            }
        }

        panel?.let { p ->
            when (p) {
                "tracks" -> TrackDialog(player, tracks, item.id, prefs, onDismiss = { panel = null })
                "settings" -> SettingsDialog(player, source, speed, { speed = it; prefs.putFloat("speed", it) }, aspect, { aspect = it; prefs.putInt("aspect", it) }, skipIntro, { skipIntro = it; prefs.putBoolean("skip_intro", it) }, skipOutro, { skipOutro = it; prefs.putBoolean("skip_outro", it) }, autoNext, { autoNext = it; prefs.putBoolean("auto_next", it) }, rememberAudio, { rememberAudio = it; prefs.putBoolean("remember_audio", it) }, rememberSubtitle, { rememberSubtitle = it; prefs.putBoolean("remember_subtitle", it) }, { panel = null })
            }
        }
        if (chapterDialog) ChapterDialog(player, source.chapters) { chapterDialog = false }
        error?.let { msg ->
            AlertDialog(onDismissRequest = { error = null }, title = { Text("播放错误") }, text = { Text(msg) }, confirmButton = { TextButton({ error = null; player.prepare(); player.play() }) { Text("重试") } })
        }
    }
}

private fun enterPip(activity: Activity?) { if (activity != null && Build.VERSION.SDK_INT >= 26) activity.enterPictureInPictureMode(PictureInPictureParams.Builder().build()) }

@Composable
private fun SettingsDialog(player: ExoPlayer, source: PlaybackSource, speed: Float, onSpeed: (Float) -> Unit, aspect: Int, onAspect: (Int) -> Unit, skipIntro: Boolean, onSkipIntro: (Boolean) -> Unit, skipOutro: Boolean, onSkipOutro: (Boolean) -> Unit, autoNext: Boolean, onAutoNext: (Boolean) -> Unit, rememberAudio: Boolean, onRememberAudio: (Boolean) -> Unit, rememberSubtitle: Boolean, onRememberSubtitle: (Boolean) -> Unit, onDismiss: () -> Unit) {
    AlertDialog(onDismissRequest = onDismiss, title = { Text("播放设置") }, text = {
        Column(Modifier.heightIn(max = 520.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Text("倍速", style = MaterialTheme.typography.titleMedium)
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) { listOf(.75f, 1f, 1.25f, 1.5f, 2f).forEach { v -> FilterChip(selected = speed == v, onClick = { onSpeed(v); player.setPlaybackSpeed(v) }, label = { Text("${v}x") }) } }
            Text("画面比例", style = MaterialTheme.typography.titleMedium)
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) { listOf(AspectRatioFrameLayout.RESIZE_MODE_FIT to "适应", AspectRatioFrameLayout.RESIZE_MODE_FILL to "填充", AspectRatioFrameLayout.RESIZE_MODE_ZOOM to "裁剪").forEach { (v, n) -> FilterChip(selected = aspect == v, onClick = { onAspect(v) }, label = { Text(n) }) } }
            HorizontalDivider()
            SettingSwitch("自动下一集", autoNext, onAutoNext)
            SettingSwitch("自动跳过片头", skipIntro, onSkipIntro)
            SettingSwitch("自动跳过片尾", skipOutro, onSkipOutro)
            SettingSwitch("记忆音轨", rememberAudio, onRememberAudio)
            SettingSwitch("记忆字幕", rememberSubtitle, onRememberSubtitle)
            SettingSwitch("保持屏幕常亮", keepScreenOn) { keepScreenOn = it; prefs.putBoolean("keep_screen_on", it); if (it) activity?.window?.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON) else activity?.window?.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON) }
            Text("视频 ${source.videoWidth ?: 0}×${source.videoHeight ?: 0} · ${source.videoCodec ?: "未知"}", style = MaterialTheme.typography.bodySmall)
            Text("音频 ${source.audioCodec ?: "未知"} · ${source.audioChannels ?: 0} 声道", style = MaterialTheme.typography.bodySmall)
        }
    }, confirmButton = { TextButton(onDismiss) { Text("完成") } })
}

@Composable private fun SettingSwitch(title: String, checked: Boolean, onChecked: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) { Text(title, Modifier.weight(1f)); Switch(checked, onChecked) }
}

@Composable
private fun TrackDialog(player: ExoPlayer, tracks: Tracks?, itemId: String, prefs: SessionStore, onDismiss: () -> Unit) {
    AlertDialog(onDismissRequest = onDismiss, title = { Text("音轨 / 字幕") }, text = {
        Column(Modifier.heightIn(max = 520.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(5.dp)) {
            Text("音频", style = MaterialTheme.typography.titleMedium)
            tracks?.groups.orEmpty().filter { it.type == C.TRACK_TYPE_AUDIO }.forEach { g -> for (i in 0 until g.length) { val f = g.getTrackFormat(i); TextButton({ prefs.putIntForItem(itemId, "audio", f.id?.toIntOrNull() ?: i); player.trackSelectionParameters = player.trackSelectionParameters.buildUpon().setOverrideForType(androidx.media3.common.TrackSelectionOverride(g.mediaTrackGroup, i)).build() }) { Text("${f.label ?: f.language ?: "音频 ${i + 1}"}${if (g.isTrackSelected(i)) " ✓" else ""}") } } }
            Text("字幕", style = MaterialTheme.typography.titleMedium)
            TextButton({ player.trackSelectionParameters = player.trackSelectionParameters.buildUpon().setTrackTypeDisabled(C.TRACK_TYPE_TEXT, true).build() }) { Text("关闭字幕") }
            tracks?.groups.orEmpty().filter { it.type == C.TRACK_TYPE_TEXT }.forEach { g -> for (i in 0 until g.length) { val f = g.getTrackFormat(i); TextButton({ prefs.putIntForItem(itemId, "subtitle", f.id?.toIntOrNull() ?: i); player.trackSelectionParameters = player.trackSelectionParameters.buildUpon().setTrackTypeDisabled(C.TRACK_TYPE_TEXT, false).setOverrideForType(androidx.media3.common.TrackSelectionOverride(g.mediaTrackGroup, i)).build() }) { Text(f.label ?: f.language ?: "字幕 ${i + 1}") } } }
        }
    }, confirmButton = { TextButton(onDismiss) { Text("完成") } })
}

private fun applyStreamOverride(player: ExoPlayer, tracks: Tracks, type: Int, streamIndex: Int) {
    tracks.groups.filter { it.type == type }.forEach { group ->
        for (i in 0 until group.length) {
            val format = group.getTrackFormat(i)
            if (format.id?.toIntOrNull() == streamIndex || i == streamIndex) {
                player.trackSelectionParameters = player.trackSelectionParameters.buildUpon()
                    .setTrackTypeDisabled(type, false)
                    .setOverrideForType(androidx.media3.common.TrackSelectionOverride(group.mediaTrackGroup, i))
                    .build()
                return
            }
        }
    }
}

private fun formatTime(ms: Long): String { val s = (ms / 1000).coerceAtLeast(0); return "%02d:%02d".format(s / 60, s % 60) }

@Composable
private fun ChapterDialog(player: ExoPlayer, chapters: List<Chapter>, onDismiss: () -> Unit) {
    AlertDialog(onDismissRequest = onDismiss, title = { Text("章节") }, text = { Column(Modifier.heightIn(max = 420.dp).verticalScroll(rememberScrollState())) {
        chapters.forEachIndexed { index, ch ->
            val selected = player.currentPosition >= ch.startTicks / 10000 && (index == chapters.lastIndex || player.currentPosition < chapters[index + 1].startTicks / 10000)
            TextButton({ player.seekTo(ch.startTicks / 10000); onDismiss() }, Modifier.fillMaxWidth()) { Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) { Text(if (selected) "▶ ${ch.name ?: "章节 ${index + 1}"}" else ch.name ?: "章节 ${index + 1}", maxLines = 1); Text(formatTime(ch.startTicks / 10000), style = MaterialTheme.typography.labelMedium) } }
        }
    } }, confirmButton = { TextButton(onDismiss) { Text("关闭") } })
}
