package com.qvey.player.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.runtime.remember
import androidx.compose.ui.unit.dp

object QveyColors {
    val Background = Color(0xFF05070B)
    val BackgroundSoft = Color(0xFF090C12)
    val Surface = Color(0xFF0D1119)
    val SurfaceRaised = Color(0xFF141A25)
    val SurfaceGlass = Color(0xB8141A25)
    val Text = Color(0xFFF6F8FC)
    val TextMuted = Color(0xFFA8B0C0)
    val TextDim = Color(0xFF70798A)
    val Accent = Color(0xFF78A9FF)
    val AccentStrong = Color(0xFF3F7EFF)
    val AccentSoft = Color(0x3378A9FF)
    val AccentGlow = Color(0x6678A9FF)
    val Success = Color(0xFF65D39A)
    val Warning = Color(0xFFFFC76A)
}

object QveyDimens {
    val Page = 20.dp
    val Section = 26.dp
    val CardRadius = 18.dp
    val HeroRadius = 26.dp
    val ChipRadius = 100.dp
    val GridGap = 12.dp
}

val QveyShapes = Shapes(
    extraSmall = RoundedCornerShape(8.dp),
    small = RoundedCornerShape(12.dp),
    medium = RoundedCornerShape(18.dp),
    large = RoundedCornerShape(24.dp),
    extraLarge = RoundedCornerShape(30.dp)
)

@Composable
fun QveyTheme(content: @Composable () -> Unit) {
    val colors = darkColorScheme(
        background = QveyColors.Background,
        surface = QveyColors.Surface,
        surfaceVariant = QveyColors.SurfaceRaised,
        primary = QveyColors.Accent,
        onPrimary = Color.White,
        primaryContainer = QveyColors.AccentSoft,
        onPrimaryContainer = Color.White,
        onBackground = QveyColors.Text,
        onSurface = QveyColors.Text,
        onSurfaceVariant = QveyColors.TextMuted,
        outline = Color(0xFF2A3344)
    )
    MaterialTheme(
        colorScheme = colors,
        shapes = QveyShapes,
        typography = Typography(
            displayLarge = MaterialTheme.typography.displayLarge.copy(color = QveyColors.Text),
            displaySmall = MaterialTheme.typography.displaySmall.copy(color = QveyColors.Text),
            headlineLarge = MaterialTheme.typography.headlineLarge.copy(color = QveyColors.Text),
            headlineMedium = MaterialTheme.typography.headlineMedium.copy(color = QveyColors.Text),
            titleLarge = MaterialTheme.typography.titleLarge.copy(color = QveyColors.Text),
            titleMedium = MaterialTheme.typography.titleMedium.copy(color = QveyColors.Text),
            bodyLarge = MaterialTheme.typography.bodyLarge.copy(color = QveyColors.Text),
            bodyMedium = MaterialTheme.typography.bodyMedium.copy(color = QveyColors.TextMuted),
            labelLarge = MaterialTheme.typography.labelLarge.copy(color = QveyColors.Text)
        ),
        content = content
    )
}

fun Modifier.qveyGlass(): Modifier =
    shadow(14.dp, QveyShapes.medium, clip = false)
        .background(
            Brush.linearGradient(listOf(Color(0xD31B2433), Color(0x9A10151F))),
            QveyShapes.medium
        )
        .border(1.dp, Color.White.copy(alpha = .09f), QveyShapes.medium)

fun Modifier.qveyHero(): Modifier =
    background(
        Brush.verticalGradient(
            listOf(Color(0xFF15243D), Color(0xFF0A101B), QveyColors.Background)
        ), QveyShapes.extraLarge
    )
    .border(1.dp, Color.White.copy(alpha = .08f), QveyShapes.extraLarge)


object QveyMotion {
    const val Fast = 160
    const val Normal = 260
    const val Emphasis = 420
}

fun Modifier.qveyHud(): Modifier =
    background(
        Brush.verticalGradient(
            listOf(Color(0xD9101622), Color(0x8A080B11))
        ),
        RoundedCornerShape(22.dp)
    ).border(1.dp, Color.White.copy(alpha = .10f), RoundedCornerShape(22.dp))

fun Modifier.qveyInteractive(): Modifier =
    shadow(10.dp, RoundedCornerShape(18.dp), clip = false)
        .border(1.dp, Color.White.copy(alpha = .08f), RoundedCornerShape(18.dp))

@Composable
fun QveyAmbientImage(modifier: Modifier = Modifier, content: @Composable () -> Unit) {
    val transition = rememberInfiniteTransition(label = "qvey-ambient")
    val scale by transition.animateFloat(
        initialValue = 1f,
        targetValue = 1.035f,
        animationSpec = infiniteRepeatable(tween(9000), RepeatMode.Reverse),
        label = "qvey-ambient-scale"
    )
    Box(modifier.graphicsLayer { scaleX = scale; scaleY = scale }) { content() }
}

@Composable
fun QveyShimmer(modifier: Modifier = Modifier) {
    val transition = rememberInfiniteTransition(label = "qvey-shimmer")
    val x by transition.animateFloat(
        initialValue = -1f,
        targetValue = 2f,
        animationSpec = infiniteRepeatable(tween(1200), RepeatMode.Restart),
        label = "qvey-shimmer-x"
    )
    val brush = Brush.linearGradient(
        colors = listOf(QveyColors.SurfaceRaised, Color(0xFF202A3A), QveyColors.SurfaceRaised),
        start = androidx.compose.ui.geometry.Offset(x * 600f, 0f),
        end = androidx.compose.ui.geometry.Offset((x + 1f) * 600f, 0f)
    )
    Box(modifier.background(brush, QveyShapes.medium))
}

@Composable
fun QveyPressable(
    modifier: Modifier = Modifier,
    onClick: () -> Unit,
    content: @Composable () -> Unit
) {
    val source = remember { MutableInteractionSource() }
    val pressed by source.collectIsPressedAsState()
    val scale = if (pressed) .975f else 1f
    Box(
        modifier = modifier
            .graphicsLayer { scaleX = scale; scaleY = scale }
            .combinedClickable(interactionSource = source, indication = null, onClick = onClick)
    ) { content() }
}

@Composable
fun QveyGestureHud(text: String, icon: ImageVector? = null, modifier: Modifier = Modifier) {
    AnimatedVisibility(
        visible = text.isNotBlank(),
        enter = fadeIn(tween(QveyMotion.Fast)) + scaleIn(tween(QveyMotion.Normal), initialScale = .88f),
        exit = fadeOut(tween(QveyMotion.Fast)) + scaleOut(tween(QveyMotion.Fast), targetScale = .94f),
        modifier = modifier
    ) {
        Row(
            Modifier.qveyHud().padding(horizontal = 22.dp, vertical = 14.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            icon?.let { Icon(it, null, tint = Color.White, modifier = Modifier.size(24.dp)) }
            Text(text, color = Color.White, style = MaterialTheme.typography.titleMedium)
        }
    }
}

fun Modifier.qveyFocus(): Modifier =
    border(1.5.dp, QveyColors.Accent.copy(alpha = .65f), QveyShapes.medium)
        .shadow(18.dp, QveyShapes.medium, clip = false)
