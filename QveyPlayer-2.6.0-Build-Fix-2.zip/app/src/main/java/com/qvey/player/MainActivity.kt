package com.qvey.player

import android.os.Bundle
import android.Manifest
import android.os.Build
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.ComponentActivity
import androidx.core.view.WindowCompat
import androidx.activity.compose.setContent
import com.qvey.player.data.SessionStore
import com.qvey.player.ui.App
import com.qvey.player.ui.MainViewModel

class MainActivity:ComponentActivity(){
 private val notificationPermission = registerForActivityResult(ActivityResultContracts.RequestPermission()) { }
 private val vm by lazy{MainViewModel(SessionStore(this))}
 override fun onCreate(savedInstanceState:Bundle?){super.onCreate(savedInstanceState)
  WindowCompat.setDecorFitsSystemWindows(window, false)
  if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != android.content.pm.PackageManager.PERMISSION_GRANTED) notificationPermission.launch(Manifest.permission.POST_NOTIFICATIONS)
  setContent{App(vm)}}
}
