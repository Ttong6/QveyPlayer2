package com.qvey.player.data

data class EmbySession(val userId:String,val token:String,val serverUrl:String,val serverName:String)
data class UserData(val played:Boolean=false,val playbackPositionTicks:Long=0,val playedPercentage:Double?=null,val isFavorite:Boolean=false)
data class EmbyItem(val id:String,val name:String,val type:String,val overview:String?,val imageTag:String?,val runTimeTicks:Long?,val userData:UserData?,val seriesId:String?=null,val parentId:String?=null,val productionYear:Int?=null,val communityRating:Double?=null,val officialRating:String?=null,val seriesName:String?=null,val seasonNumber:Int?=null,val episodeNumber:Int?=null)
data class Chapter(val startTicks:Long,val endTicks:Long,val name:String?)
data class PlaybackSource(val mediaSourceId:String,val url:String,val mimeType:String?,val playSessionId:String?,val playMethod:String,val videoCodec:String?=null,val audioCodec:String?=null,val videoHeight:Int?=null,val videoWidth:Int?=null,val audioChannels:Int?=null,val audioStreamIndex:Int?=null,val subtitleStreamIndex:Int?=null,val streams:List<MediaStream> = emptyList(),val chapters:List<Chapter> = emptyList())
data class Library(val id:String,val name:String,val collectionType:String?,val imageTag:String?)
data class MediaStream(val index:Int,val type:String,val codec:String?,val language:String?,val title:String?,val displayTitle:String?,val isDefault:Boolean=false,val isForced:Boolean=false)
