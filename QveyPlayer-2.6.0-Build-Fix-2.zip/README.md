# Qvey Player 2.6.0

Qvey Player 是一个面向 **原生 Android 手机** 的 Emby 客户端，使用 Jetpack Compose、Material 3、Coil、OkHttp 与 AndroidX Media3/ExoPlayer。

## 2.6.0 — Build Ready & Stability

- 面向手机端，不加入 Android TV / 平板专用布局。
- Android Edge-to-Edge 与沉浸式播放器。
- Media3 音频焦点与耳机拔出处理。
- 双击快进/快退、亮度/音量手势、Seek 时间预览。
- PIP、MediaSession、通知栏、章节、自动下一集。
- Emby Direct Play / Direct Stream / Transcode 播放链路。
- 音轨 / 字幕选择与记忆。
- GitHub Actions 自动构建 APK。
- Push 到 `main` / `master` 或手动运行 `Qvey Player APK` 工作流即可生成 Debug APK Artifact。
- 推送 `v*` 标签或手动运行 `Qvey Player Release APK` 可创建 GitHub Release 并附带 APK。

## GitHub Actions 构建

本工程没有要求本地电脑安装 Android Studio。GitHub Actions 会自动准备 JDK 17、Android SDK、Build Tools 36.0.0 与 Gradle 9.3.1，然后执行 `:app:assembleDebug`。

AGP 9.1.1 官方兼容 Gradle 9.3.1、JDK 17 和 Build Tools 36.0.0。

### 手机直接使用 APK

1. 将项目上传到 GitHub。
2. 打开仓库的 **Actions**。
3. 选择 **Qvey Player APK**。
4. 点击 **Run workflow**。
5. 等待构建完成。
6. 在本次运行页面的 **Artifacts** 下载 `QveyPlayer-2.6.0-debug`。
7. 在 Android 手机上安装 `app-debug.apk`。

### GitHub Release

发布版本时创建例如 `v2.6.0` 的 tag，`Qvey Player Release APK` 会自动构建并把 APK 附到 GitHub Release。

## Build

GitHub Actions 是当前推荐的无电脑构建方式。若以后使用 Android Studio，工程也可以直接导入后构建。

## GitHub Actions build

This project includes Gradle launcher files and a GitHub Actions workflow. The workflow provisions Gradle 9.3.1 and builds the debug APK with `./gradlew`.


## Build Fix 2
Migrated to AGP 9 built-in Kotlin. The legacy `org.jetbrains.kotlin.android`
plugin is removed, while the Compose Kotlin plugin remains. GitHub Actions
uses JDK 17 and Gradle 9.3.1 and builds `:app:assembleDebug`.
