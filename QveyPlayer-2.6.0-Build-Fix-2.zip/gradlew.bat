@echo off
where gradle >nul 2>nul
if %ERRORLEVEL% EQU 0 (
  gradle %*
  exit /b %ERRORLEVEL%
)
echo ERROR: Gradle is not installed. GitHub Actions must provision Gradle before running this launcher.
exit /b 1
